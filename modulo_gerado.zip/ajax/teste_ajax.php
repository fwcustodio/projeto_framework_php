<?php
    require_once('../../sis/framework/config.conf.php'); ConfigSIS::Conf(); ConfigSIS::load(); $TesteController = new TesteController();

 switch ($_GET['Op']){
     case 'myOption': echo true;
         break;
     default : echo false;
 }
    
    
    class TesteAjax extends AjaxBase {
        //put your code here
    }

?>