<?

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of form
 *
 * @author
 */
class TesteForm extends FormBase {

    public function TesteForm() {
        parent::FormCampos();
    }

    public function getFormManu() {
        $Metodo = "POST";
        $Op = $_GET['Op'];
        
        $ArrayForm["Campo1"] = parent::inputTexto(array(
                    "Nome" => "Campo1",
                    "Identifica" => "Campo1",
                    "Valor" => parent::retornaValor($Metodo, "Campo1"),
                    "Id" => "Campo1",
                    "Largura" => 30,
                    "Min" => 1,
                    "Max" => 30,
                    "Tratar" => array("L", "H", "A"),
                    "ValidaJS" => true,
                    "Adicional" => "style='width:180px;'"), true);

        $ArrayForm["Campo2"] = parent::listaVetor(array(
                    "Nome" => "Campo2",
                    "Identifica" => "Campo2",
                    "Valor" => parent::retornaValor($Metodo, "Campo2"),
                    "Status" => true,
                    "ValidaJS" => false,
                    "Inicio" => true,
                    "Vetor" => array("C" => "Componente", "I" => "Modulo")), false);

        $ArrayForm["Submit"] = parent::botao(array(
                    "Nome" => "Submit",
                    "Identifica" => "Submit",
                    "Tipo" => "button",
                    "Estilo" => "cursor:pointer;margin-top:50px;",
                    "Adicional" => " class=\"botaoForm\" onClick=\"if(validaForm())minhaFuncaoCadastro()}\""));
        return $ArrayForm;
    }
}
?>