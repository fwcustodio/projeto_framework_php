function ajaxBasico(){
    $.ajax({
        url: UrlBaseSite+'teste/ajax/teste_ajax.php?Op=getResposta&Env=true',
        type: 'POST',
        datatype:'html',
        data: $('#FormManu').serialize(),
        complete:function(Req){
            retornoAjaxBasico(Req.responseText);
        }
    });
}