<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of controller
 *
 * @author
 */
class TesteController extends ControllerBase {    
    private $TesteModel;
    

    public function __construct() {
        $this->TesteModel = new TesteModel();
    }    
    
    
    //Constante m�dulo setada automaticamente no ConfigSis    
    public function init(){        
        $DadosViews = array(
            'conteudo' => array(
                'Nomes' => array('Luis','Claudio','Paulo')
            )
        );
        $ArrayConfig = array(
            array(
                'ViewLayout' => 'Conteudo',
                'View' => 'conteudo',
                'Modulo' => Modulo
                )
        );
        return array(
            'Config' => $ArrayConfig,
            'Dados' => $DadosViews
        );
    }
    
    //Script e estilos que ser�o adicionados ao layout
    public function getScripts(){
        return array(
            parent::getScript('JS',$_SESSION['UrlBaseSite'].Modulo.'/js/main.js'),
            parent::getScript('CSS', $_SESSION['UrlBaseSite'].Modulo.'/css/main.css')
        );
    }    

    
    public function getParametros(){
        return array(
            'TituloPaginaInterna' => 'Teste'
        );
    }
}
?>