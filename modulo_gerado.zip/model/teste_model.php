<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of model
 *
 * @author
 */
class TesteModel extends ModelBase {
    
    function __construct() {
        parent::ModelBase();
    }
    
        public function getDados(){
//        $Sql = 'SELECT SecaoCod, SecaoNome, Link, LinkTipo, LinkTarget
//                FROM secao
//                WHERE Publicar = "S"
//                AND Situacao = "A"
//                ORDER BY SecaoPosicao';
//        return parent::getConexaoBD()->execTodosArray($Sql);
    }
}
?>