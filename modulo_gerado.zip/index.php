<?php
require_once('../sis/framework/config.conf.php'); ConfigSIS::Conf(); ConfigSIS::load(); $TesteController = new TesteController();

$Front = FrontController::getInstancia();
$Front->setLayout('padrao');
$Front->setViews($TesteController->init());
$Front->setScripts($TesteController->getScripts());
$Front->setParametros($TesteController->getParametros());
$Front->renderizarPagina();